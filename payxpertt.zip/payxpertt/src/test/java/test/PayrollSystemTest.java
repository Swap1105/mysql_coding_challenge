package test;

import static org.junit.jupiter.api.Assertions.*;

import exception.InvalidInputException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import entity.Employee;
import entity.Payroll;
import exception.PayrollGenerationException;
import exception.TaxCalculationException;
import service.EmployeeServiceImpl;
import service.PayrollServiceImpl;
import service.TaxServiceImpl;

public class PayrollSystemTest {

    private EmployeeServiceImpl employeeService;
    private PayrollServiceImpl payrollService;
    private TaxServiceImpl taxService;

    @BeforeEach
    public void setUp() {
        employeeService = new EmployeeServiceImpl();
        payrollService = new PayrollServiceImpl();
        taxService = new TaxServiceImpl();
    }

    @Test
    public void testCalculateGrossSalaryForEmployee() {
        // Given
        Employee employee = new Employee(1, "John", "Doe", "1990-01-01", "M", "john.doe@example.com", 
                                          "1234567890", "123 Main St", "Developer", "2022-01-01", null);
        double basicSalary = 5000.00;
        double overtimePay = 1000.00;
        double expectedGrossSalary = basicSalary + overtimePay;

        // When
        double calculatedGrossSalary = basicSalary + overtimePay;

        // Then
        assertEquals(expectedGrossSalary, calculatedGrossSalary, "Gross salary calculation is incorrect");
    }

    @Test
    public void testCalculateNetSalaryAfterDeductions() {
        // Given
        double grossSalary = 6000.00;
        double totalDeductions = 1500.00;
        double expectedNetSalary = grossSalary - totalDeductions;

        // When
        double calculatedNetSalary = grossSalary - totalDeductions;

        // Then
        assertEquals(expectedNetSalary, calculatedNetSalary, "Net salary calculation is incorrect");
    }

    @Test
    public void testVerifyTaxCalculationForHighIncomeEmployee() throws TaxCalculationException {
        // Given
        int employeeId = 1; // Assume this is a high-income employee
        int taxYear = 2023;
        double expectedTaxAmount = 9000.00; // Expected tax amount for the high-income employee

        // When
        double calculatedTaxAmount = taxService.calculateTax(employeeId, taxYear);

        // Then
        assertEquals(expectedTaxAmount, calculatedTaxAmount, "Tax calculation for high-income employee is incorrect");
    }

    @Test
    public void testProcessPayrollForMultipleEmployees() throws PayrollGenerationException {
        // Given
        Employee employee1 = new Employee(1, "Alice", "Smith", "1985-05-15", "F", "alice.smith@example.com", 
                                           "0987654321", "456 Elm St", "Manager", "2020-01-01", null);
        Employee employee2 = new Employee(2, "Bob", "Johnson", "1992-03-20", "M", "bob.johnson@example.com", 
                                           "1234567890", "789 Oak St", "Analyst", "2021-01-01", null);
        double basicSalary1 = 7000.00;
        double basicSalary2 = 4000.00;
        double overtimePay1 = 500.00;
        double overtimePay2 = 300.00;

        // Process payroll for employee 1
        Payroll payroll1 = new Payroll(0, employee1.getEmployeeID(), "2023-01-01", "2023-01-15", 
                                        basicSalary1, overtimePay1, 0, basicSalary1 + overtimePay1);
        payrollService.generatePayroll(payroll1);

        // Process payroll for employee 2
        Payroll payroll2 = new Payroll(0, employee2.getEmployeeID(), "2023-01-01", "2023-01-15", 
                                        basicSalary2, overtimePay2, 0, basicSalary2 + overtimePay2);
        payrollService.generatePayroll(payroll2);

        // Verify payroll records (this would typically involve checking the database)
        assertNotNull(payroll1, "Payroll for employee 1 should not be null");
        assertNotNull(payroll2, "Payroll for employee 2 should not be null");
    }

    @Test
    public void testVerifyErrorHandlingForInvalidEmployeeData() {
        // Given
        Employee invalidEmployee = new Employee(0, "", "", "", "M", "invalid-email", 
                                                "1234567890", "123 Main St", "Developer", "2022-01-01", null);

        // When & Then
        Exception exception = assertThrows(InvalidInputException.class, () -> {
            employeeService.addEmployee(invalidEmployee);
        });

        String expectedMessage = "First name cannot be empty";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage), "Error handling for invalid employee data failed");
    }
}