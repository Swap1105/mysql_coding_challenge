package dao;

import entity.Employee;
import exception.EmployeeNotFoundException;
import util.DBConnUtil;
import util.DBPropertyUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmployeeDaoImpl implements IEmployeeDao {
    private static final String CONN_STRING = DBPropertyUtil.getConnectionString("src/main/resources/db.properties");

    @Override
    public void addEmployee(Employee employee) throws Exception {
        String query = "INSERT INTO Employee (FirstName, LastName, DateOfBirth, Gender, Email, PhoneNumber, Address, Position, JoiningDate, TerminationDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, employee.getFirstName());
            stmt.setString(2, employee.getLastName());
            stmt.setString(3, employee.getDateOfBirth());
            stmt.setString(4, employee.getGender());
            stmt.setString(5, employee.getEmail());
            stmt.setString(6, employee.getPhoneNumber());
            stmt.setString(7, employee.getAddress());
            stmt.setString(8, employee.getPosition());
            stmt.setString(9, employee.getJoiningDate());
            stmt.setString(10, employee.getTerminationDate());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new Exception("Error adding employee: " + e.getMessage());
        }
    }

    @Override
    public Employee getEmployeeById(int employeeId) throws EmployeeNotFoundException {
        String query = "SELECT * FROM Employee WHERE EmployeeID = ?";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Employee(
                        rs.getInt("EmployeeID"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("DateOfBirth"),
                        rs.getString("Gender"),
                        rs.getString("Email"),
                        rs.getString("PhoneNumber"),
                        rs.getString("Address"),
                        rs.getString("Position"),
                        rs.getString("JoiningDate"),
                        rs.getString("TerminationDate")
                );
            } else {
                throw new EmployeeNotFoundException("Employee with ID " + employeeId + " not found");
            }
        } catch (SQLException e) {
            throw new EmployeeNotFoundException("Error fetching employee: " + e.getMessage());
        }
    }

    @Override
    public void updateEmployee(Employee employee) throws EmployeeNotFoundException {
        String query = "UPDATE Employee SET FirstName = ?, LastName = ?, DateOfBirth = ?, Gender = ?, Email = ?, PhoneNumber = ?, Address = ?, Position = ?, JoiningDate = ?, TerminationDate = ? WHERE EmployeeID = ?";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, employee.getFirstName());
            stmt.setString(2, employee.getLastName());
            stmt.setString(3, employee.getDateOfBirth());
            stmt.setString(4, employee.getGender());
            stmt.setString(5, employee.getEmail());
            stmt.setString(6, employee.getPhoneNumber());
            stmt.setString(7, employee.getAddress());
            stmt.setString(8, employee.getPosition());
            stmt.setString(9, employee.getJoiningDate());
            stmt.setString(10, employee.getTerminationDate());
            stmt.setInt(11, employee.getEmployeeID());
            int rows = stmt.executeUpdate();
            if (rows == 0) {
                throw new EmployeeNotFoundException("Employee with ID " + employee.getEmployeeID() + " not found");
            }
        } catch (SQLException e) {
            throw new EmployeeNotFoundException("Error updating employee: " + e.getMessage());
        }
    }

    @Override
    public void deleteEmployee(int employeeId) throws EmployeeNotFoundException {
        String query = "DELETE FROM Employee WHERE EmployeeID = ?";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            int rows = stmt.executeUpdate();
            if (rows == 0) {
                throw new EmployeeNotFoundException("Employee with ID " + employeeId + " not found");
            }
        } catch (SQLException e) {
            throw new EmployeeNotFoundException("Error deleting employee: " + e.getMessage());
        }
    }
}