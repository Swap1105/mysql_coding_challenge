package dao;

import entity.Employee;
import exception.EmployeeNotFoundException;

public interface IEmployeeDao {
    void addEmployee(Employee employee) throws Exception;
    Employee getEmployeeById(int employeeId) throws EmployeeNotFoundException;
    void updateEmployee(Employee employee) throws EmployeeNotFoundException;
    void deleteEmployee(int employeeId) throws EmployeeNotFoundException;
}