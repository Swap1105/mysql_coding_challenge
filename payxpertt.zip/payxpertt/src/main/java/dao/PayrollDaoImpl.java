package dao;

import entity.Payroll;
import exception.PayrollGenerationException;
import util.DBConnUtil;
import util.DBPropertyUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PayrollDaoImpl implements IPayrollDao {
    private static final String CONN_STRING = DBPropertyUtil.getConnectionString("src/main/resources/db.properties");

    @Override
    public void generatePayroll(Payroll payroll) throws PayrollGenerationException {
        String query = "INSERT INTO Payroll (EmployeeID, PayPeriodStartDate, PayPeriodEndDate, BasicSalary, OvertimePay, Deductions, NetSalary) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, payroll.getEmployeeID());
            stmt.setString(2, payroll.getPayPeriodStartDate());
            stmt.setString(3, payroll.getPayPeriodEndDate());
            stmt.setDouble(4, payroll.getBasicSalary());
            stmt.setDouble(5, payroll.getOvertimePay());
            stmt.setDouble(6, payroll.getDeductions());
            stmt.setDouble(7, payroll.getNetSalary());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new PayrollGenerationException("Error generating payroll: " + e.getMessage());
        }
    }
}