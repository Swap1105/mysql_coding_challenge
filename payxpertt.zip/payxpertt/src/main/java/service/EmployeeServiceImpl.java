package service;

import dao.IEmployeeDao;
import dao.EmployeeDaoImpl;
import entity.Employee;
import exception.EmployeeNotFoundException;
import exception.InvalidInputException;

public class EmployeeServiceImpl implements IEmployeeService {
    private final IEmployeeDao employeeDao;

    public EmployeeServiceImpl() {
        this.employeeDao = new EmployeeDaoImpl();
    }

    @Override
    public void addEmployee(Employee employee) throws Exception {
        validateEmployee(employee);
        employeeDao.addEmployee(employee);
    }

    @Override
    public Employee getEmployeeById(int employeeId) throws EmployeeNotFoundException {
        if (employeeId <= 0) {
            throw new EmployeeNotFoundException("Invalid Employee ID: " + employeeId);
        }
        return employeeDao.getEmployeeById(employeeId);
    }

    @Override
    public void updateEmployee(Employee employee) throws EmployeeNotFoundException, InvalidInputException {
        validateEmployee(employee);
        employeeDao.updateEmployee(employee);
    }

    @Override
    public void deleteEmployee(int employeeId) throws EmployeeNotFoundException {
        if (employeeId <= 0) {
            throw new EmployeeNotFoundException("Invalid Employee ID: " + employeeId);
        }
        employeeDao.deleteEmployee(employeeId);
    }

    @Override
    public void validateEmployee(Employee employee) throws InvalidInputException {
        if (employee.getFirstName() == null || employee.getFirstName().trim().isEmpty()) {
            throw new InvalidInputException("First name cannot be empty");
        }
        if (employee.getLastName() == null || employee.getLastName().trim().isEmpty()) {
            throw new InvalidInputException("Last name cannot be empty");
        }
        if (employee.getEmail() == null || !employee.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            throw new InvalidInputException("Invalid email format");
        }
        if (employee.getJoiningDate() == null || employee.getJoiningDate().trim().isEmpty()) {
            throw new InvalidInputException("Joining date cannot be empty");
        }
    }
}