package service;

import dao.ITaxDao;
import dao.TaxDaoImpl;
import entity.Tax;
import exception.TaxCalculationException;

import java.util.List;

public class TaxServiceImpl implements ITaxService {
    private final ITaxDao taxDao;

    public TaxServiceImpl() {
        this.taxDao = new TaxDaoImpl();
    }

    @Override
    public double calculateTax(int employeeId, int taxYear) throws TaxCalculationException {
        if (employeeId <= 0 || taxYear <= 0) {
            throw new TaxCalculationException("Invalid employee ID or tax year");
        }
        return taxDao.calculateTax(employeeId, taxYear);
    }

    @Override
    public Tax getTaxById(int taxId) throws TaxCalculationException {
        if (taxId <= 0) {
            throw new TaxCalculationException("Invalid Tax ID: " + taxId);
        }
        return taxDao.getTaxById(taxId);
    }

    @Override
    public List<Tax> getTaxesForEmployee(int employeeId) throws TaxCalculationException {
        if (employeeId <= 0) {
            throw new TaxCalculationException("Invalid Employee ID: " + employeeId);
        }
        return taxDao.getTaxesForEmployee(employeeId);
    }

    @Override
    public List<Tax> getTaxesForYear(int taxYear) throws TaxCalculationException {
        if (taxYear <= 0) {
            throw new TaxCalculationException("Invalid Tax Year: " + taxYear);
        }
        return taxDao.getTaxesForYear(taxYear);
    }
}