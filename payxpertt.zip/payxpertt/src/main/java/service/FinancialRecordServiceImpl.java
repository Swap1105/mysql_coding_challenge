package service;

import dao.IFinancialRecordDao;
import dao.FinancialRecordDaoImpl;
import entity.FinancialRecord;
import exception.FinancialRecordException;

import java.util.List;

public class FinancialRecordServiceImpl implements IFinancialRecordService {
    private final IFinancialRecordDao financialRecordDao;

    public FinancialRecordServiceImpl() {
        this.financialRecordDao = new FinancialRecordDaoImpl();
    }

    @Override
    public void addFinancialRecord(int employeeId, String description, double amount, String recordType, String recordDate) throws FinancialRecordException {
        if (employeeId <= 0 || description == null || recordType == null || recordDate == null) {
            throw new FinancialRecordException("Invalid input for financial record");
        }
        financialRecordDao.addFinancialRecord(employeeId, description, amount, recordType, recordDate);
    }

    @Override
    public FinancialRecord getFinancialRecordById(int recordId) throws FinancialRecordException {
        if (recordId <= 0) {
            throw new FinancialRecordException("Invalid Record ID: " + recordId);
        }
        return financialRecordDao.getFinancialRecordById(recordId);
    }

    @Override
    public List<FinancialRecord> getFinancialRecordsForEmployee(int employeeId) throws FinancialRecordException {
        if (employeeId <= 0) {
            throw new FinancialRecordException("Invalid Employee ID: " + employeeId);
        }
        return financialRecordDao.getFinancialRecordsForEmployee(employeeId);
    }

    @Override
    public List<FinancialRecord> getFinancialRecordsForDate(String recordDate) throws FinancialRecordException {
        if (recordDate == null || recordDate.trim().isEmpty()) {
            throw new FinancialRecordException("Record date cannot be empty");
        }
        return financialRecordDao.getFinancialRecordsForDate(recordDate);
    }
}