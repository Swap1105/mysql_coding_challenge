package service;

import entity.Employee;
import exception.EmployeeNotFoundException;
import exception.InvalidInputException;

public interface IEmployeeService {
    void addEmployee(Employee employee) throws Exception;
    Employee getEmployeeById(int employeeId) throws EmployeeNotFoundException;
    void updateEmployee(Employee employee) throws EmployeeNotFoundException, InvalidInputException;
    void deleteEmployee(int employeeId) throws EmployeeNotFoundException;
    void validateEmployee(Employee employee) throws InvalidInputException;
}