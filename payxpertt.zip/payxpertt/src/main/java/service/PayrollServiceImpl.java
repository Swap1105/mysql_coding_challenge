package service;

import dao.IPayrollDao;
import dao.PayrollDaoImpl;
import entity.Payroll;
import exception.PayrollGenerationException;
import exception.InvalidInputException;

public class PayrollServiceImpl implements IPayrollService {
    private final IPayrollDao payrollDao;

    public PayrollServiceImpl() {
        this.payrollDao = new PayrollDaoImpl();
    }

    @Override
    public void generatePayroll(Payroll payroll) throws PayrollGenerationException {
        validatePayroll(payroll);
        payrollDao.generatePayroll(payroll);
    }

    private void validatePayroll(Payroll payroll) throws PayrollGenerationException {
        if (payroll.getEmployeeID() <= 0) {
            throw new PayrollGenerationException("Invalid Employee ID: " + payroll.getEmployeeID());
        }
        if (payroll.getPayPeriodStartDate() == null || payroll.getPayPeriodEndDate() == null) {
            throw new PayrollGenerationException("Pay period dates cannot be null");
        }
        if (payroll.getBasicSalary() < 0 || payroll.getOvertimePay() < 0 || payroll.getDeductions() < 0) {
            throw new PayrollGenerationException("Salary components cannot be negative");
        }
        if (payroll.getNetSalary() != (payroll.getBasicSalary() + payroll.getOvertimePay() - payroll.getDeductions())) {
            throw new PayrollGenerationException("Net salary calculation mismatch");
        }
    }
}