package dao;

import entity.*;
import exception.PatientNumberNotFoundException;
import util.DBConnUtil;
import util.DBPropertyUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static java.sql.Date.valueOf;

public class HospitalServiceImpl implements IHospitalService{
    private static final String CONN_STRING = DBPropertyUtil.getConnectionString("src/main/resources/db.properties");

    @Override
    public boolean addPatient(Patient patient) {
        String query = "INSERT INTO patient (patientId, firstName, lastName, dateOfBirth, gender, contactNumber, address) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, patient.getPatientId());
            ps.setString(2, patient.getFirstName());
            ps.setString(3, patient.getLastName());
            ps.setDate(4, Date.valueOf(patient.getDateOfBirth()));
            ps.setString(5, patient.getGender());
            ps.setString(6, patient.getContactNumber());
            ps.setString(7, patient.getAddress());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean addDoctor(Doctor doctor) {
        String query = "INSERT INTO doctor (doctorId, firstName, lastName, specialization, contactNumber) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, doctor.getDoctorId());
            ps.setString(2, doctor.getFirstName());
            ps.setString(3, doctor.getLastName());
            ps.setString(4, doctor.getSpecialization());
            ps.setString(5, doctor.getContactNumber());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    @Override
    public Appointment getAppointmentById(int appointmentId){
        Appointment appointment = null;
        String query = "select * from appointment where appointmentid = ?";
        try(Connection conn = DBConnUtil.getConnection(CONN_STRING);
        PreparedStatement ps = conn.prepareStatement(query)){
            ps.setInt(1, appointmentId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()){
                appointment = new Appointment(
                        rs.getInt("appointmentId"),
                        rs.getInt("patientId"),
                        rs.getInt("doctorId"),
                        rs.getDate("appointmentDate").toLocalDate(),
                        rs.getString("description")
                );
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return appointment;
    }

    @Override
    public List<Appointment> getAppointmentsForPatient(int patientId){
        List<Appointment> appointments = new ArrayList<>();
        String query = "select * from appointment where patientId = ?";
        try(Connection conn = DBConnUtil.getConnection(CONN_STRING);
            PreparedStatement ps = conn.prepareStatement(query)){
            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()){
                appointments.add(new Appointment(
                        rs.getInt("appointmentId"),
                        rs.getInt("patientId"),
                        rs.getInt("doctorId"),
                        rs.getDate("appointmentDate").toLocalDate(),
                        rs.getString("description")
                ));
            }
            if (appointments.isEmpty()){
                throw new PatientNumberNotFoundException("No appointments for Patient ID: "+ patientId);
            }
        }catch (SQLException | PatientNumberNotFoundException e){
            e.printStackTrace();
        }
        return appointments;
    }

    @Override
    public List<Appointment> getAppointmentsForDoctor(int doctorId){
        List<Appointment> appointments = new ArrayList<>();
        String query = "select * from appointment where doctorId = ?";
        try(Connection conn = DBConnUtil.getConnection(CONN_STRING);
            PreparedStatement ps = conn.prepareStatement(query)){
            ps.setInt(1, doctorId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()){
                appointments.add(new Appointment(
                        rs.getInt("appointmentId"),
                        rs.getInt("patientId"),
                        rs.getInt("doctorId"),
                        rs.getDate("appointmentDate").toLocalDate(),
                        rs.getString("description")
                ));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return appointments;
    }

    @Override
    public boolean scheduleAppointment(Appointment appointment){
        String query = "insert into appointment (appointmentid, patientid, doctorid, appointmentdate, description) values (?,?,?,?,?)";
        try(Connection conn = DBConnUtil.getConnection(CONN_STRING);
            PreparedStatement ps = conn.prepareStatement(query)){
            ps.setInt(1, appointment.getAppointmentId());
            ps.setInt(2, appointment.getPatientId());
            ps.setInt(3, appointment.getDoctorId());
            ps.setDate(4, valueOf(appointment.getAppointmentDate()));
            ps.setString(5, appointment.getDescription());

            return ps.executeUpdate()>0;

            } catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateAppointment(Appointment appointment){
        String query = "update appointment set patientId = ?, doctorId=?, appointmentDate=?, description=? where appointmentId=?";
        try(Connection conn = DBConnUtil.getConnection(CONN_STRING);
            PreparedStatement ps = conn.prepareStatement(query)){
            ps.setInt(1, appointment.getPatientId());
            ps.setInt(2, appointment.getDoctorId());
            ps.setDate(3, Date.valueOf(appointment.getAppointmentDate()));
            ps.setString(4, appointment.getDescription());
            ps.setInt(5, appointment.getAppointmentId());

            return ps.executeUpdate()>0;

        } catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean cancelAppointment(Appointment appointment) {
        String query = "delete from appointment where appointmentId=?";
        try (Connection conn = DBConnUtil.getConnection(CONN_STRING);
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, appointment.getAppointmentId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
