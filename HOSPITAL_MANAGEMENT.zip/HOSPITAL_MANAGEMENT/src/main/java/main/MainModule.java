package main;

import dao.HospitalServiceImpl;
import entity.Appointment;
import entity.Patient;
import entity.Doctor;
import java.time.LocalDate;
import java.util.Scanner;

public class MainModule {
    private static HospitalServiceImpl service = new HospitalServiceImpl();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("Welcome to the Hospital Management System");
            System.out.println("1. Get Appointment by ID");
            System.out.println("2. Get Appointments for Patient");
            System.out.println("3. Schedule Appointment");
            System.out.println("4. Update Appointment");
            System.out.println("5. Cancel Appointment");
            System.out.println("6. Add New Patient");
            System.out.println("7. Add New Doctor");
            System.out.println("0. Exit");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    getAppointmentById();
                    break;
                case 2:
                    getAppointmentsForPatient();
                    break;
                case 3:
                    scheduleAppointment();
                    break;
                case 4:
                    updateAppointment();
                    break;
                case 5:
                    cancelAppointment();
                    break;
                case 6:
                    addNewPatient();
                    break;
                case 7:
                    addNewDoctor();
                    break;
                case 0:
                    System.out.println("Exiting the system. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
        sc.close();
    }

    private static void getAppointmentById() {
        System.out.print("Enter Appointment ID: ");
        int aid = sc.nextInt();
        Appointment appointment = service.getAppointmentById(aid);
        if (appointment != null) {
            System.out.println("Appointment Details: " + appointment);
        } else {
            System.out.println("No appointment found with ID: " + aid);
        }
    }

    private static void getAppointmentsForPatient() {
        System.out.print("Enter Patient ID: ");
        int pid = sc.nextInt();
        try {
            System.out.println("Appointments for Patient ID " + pid + ": " + service.getAppointmentsForPatient(pid));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void scheduleAppointment() {
        System.out.print("Enter Appointment ID: ");
        int appointmentId = sc.nextInt();
        System.out.print("Enter Patient ID: ");
        int patientId = sc.nextInt();
        System.out.print("Enter Doctor ID: ");
        int doctorId = sc.nextInt();
        System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
        String date = sc.next();
        System.out.print("Enter Description: ");
        String description = sc.next();

        Appointment appointment = new Appointment(appointmentId, patientId, doctorId, LocalDate.parse(date), description);
        boolean success = service.scheduleAppointment(appointment);
        if (success) {
            System.out.println("Appointment scheduled successfully.");
        } else {
            System.out.println("Failed to schedule appointment.");
        }
    }

    private static void updateAppointment() {
        System.out.print("Enter Appointment ID to update: ");
        int appointmentId = sc.nextInt();
        System.out.print("Enter new Patient ID: ");
        int patientId = sc.nextInt();
        System.out.print("Enter new Doctor ID: ");
        int doctorId = sc.nextInt();
        System.out.print("Enter new Appointment Date (YYYY-MM-DD): ");
        String date = sc.next();
        System.out.print("Enter new Description: ");
        String description = sc.next();

        Appointment appointment = new Appointment(appointmentId, patientId, doctorId, LocalDate.parse(date), description);
        boolean success = service.updateAppointment(appointment);
        if (success) {
            System.out.println("Appointment updated successfully.");
        } else {
            System.out.println("Failed to update appointment.");
        }
    }

    private static void cancelAppointment() {
        System.out.print("Enter Appointment ID to cancel: ");
        int appointmentId = sc.nextInt();
        Appointment appointment = new Appointment();
        appointment.setAppointmentId(appointmentId);
        boolean success = service.cancelAppointment(appointment);
        if (success) {
            System.out.println("Appointment canceled successfully.");
        } else {
            System.out.println("Failed to cancel appointment.");
        }
    }

    private static void addNewPatient() {
        System.out.print("Enter Patient ID: ");
        int patientId = sc.nextInt();
        System.out.print("Enter First Name: ");
        String firstName = sc.next();
        System.out.print("Enter Last Name: ");
        String lastName = sc.next();
        System.out.print("Enter Date of Birth (YYYY-MM-DD): ");
        String dob = sc.next();
        System.out.print("Enter Gender: ");
        String gender = sc.next();
        System.out.print("Enter Contact Number: ");
        String contactNumber = sc.next();
        System.out.print("Enter Address: ");
        String address = sc.next();

        Patient patient = new Patient(patientId, firstName, lastName, LocalDate.parse(dob), gender, contactNumber, address);
        // Assuming a method to add patient exists in the service
        boolean success = service.addPatient(patient);
        if (success) {
            System.out.println("Patient added successfully.");
        } else {
            System.out.println("Failed to add patient.");
        }
    }

    private static void addNewDoctor() {
        System.out.print("Enter Doctor ID: ");
        int doctorId = sc.nextInt();
        System.out.print("Enter First Name: ");
        String firstName = sc.next();
        System.out.print("Enter Last Name: ");
        String lastName = sc.next();
        System.out.print("Enter Specialization: ");
        String specialization = sc.next();
        System.out.print("Enter Contact Number: ");
        String contactNumber = sc.next();

        Doctor doctor = new Doctor(doctorId, firstName, lastName, specialization, contactNumber);
        // Assuming a method to add doctor exists in the service
        boolean success = service.addDoctor(doctor);
        if (success) {
            System.out.println("Doctor added successfully.");
        } else {
            System.out.println("Failed to add doctor.");
        }
    }
}