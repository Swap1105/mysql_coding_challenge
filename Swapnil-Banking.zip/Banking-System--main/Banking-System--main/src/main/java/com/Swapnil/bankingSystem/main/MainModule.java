

package com.Swapnil.bankingSystem.main;

import java.util.Scanner;
import com.Swapnil.bankingSystem.doa.LoanService;
import com.Swapnil.bankingSystem.doa.LoanServiceImpl;
import com.Swapnil.bankingSystem.entity.Customer;
import com.Swapnil.bankingSystem.exception.LoanNotEligibleException;

public class MainModule {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("==== Loan Eligibility Check ====");
        System.out.print("Enter credit score: ");
        int creditScore = sc.nextInt();

        System.out.print("Enter annual income: ");
        double income = sc.nextDouble();

        // Create Customer object
        Customer customer = new Customer(creditScore, income);

        // Use LoanService
        LoanService service = new LoanServiceImpl();

        try {
            if (service.isEligibleForLoan(customer)) {
                System.out.println("Congratulations! You are eligible for a loan.");
            }
        } catch (LoanNotEligibleException e) {
            System.out.println("Loan Denied: " + e.getMessage());
        }

        System.out.println("\n==== ATM Transaction Simulation ====");
        System.out.println("Choose an option:\n1. Check Balance\n2. Deposit\n3. Withdraw");
        int choice = sc.nextInt();

        System.out.print("Enter current balance: $");
        double balance = sc.nextDouble();

        switch (choice) {
            case 1:
                System.out.println("Your current balance is: $" + balance);
                break;
            case 2:
                System.out.print("Enter amount to deposit: $");
                double deposit = sc.nextDouble();
                balance += deposit;
                System.out.println("Deposit successful. Updated balance: $" + balance);
                break;
            case 3:
                System.out.print("Enter amount to withdraw (multiples of 100 or 500): $");
                double withdraw = sc.nextDouble();
                if (withdraw > balance) {
                    System.out.println("Withdrawal failed: Insufficient funds.");
                } else if (withdraw % 100 != 0 && withdraw % 500 != 0) {
                    System.out.println("Withdrawal failed: Amount should be in multiples of 100 or 500.");
                } else {
                    balance -= withdraw;
                    System.out.println("Withdrawal successful. Updated balance: $" + balance);
                }
                break;
            default:
                System.out.println("Invalid choice.");
        }

        sc.close();
    }
}
