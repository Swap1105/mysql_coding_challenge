package com.Swapnil.bankingSystem.entity;

public class AccountDetails {
    private long accountNumber;
    private String customerName;
    private float balance;

    public AccountDetails() {
        // Default constructor
    }

    public AccountDetails(long accountNumber, String customerName, float balance) {
        this.accountNumber = accountNumber;
        this.customerName = customerName;
        this.balance = balance;
    }

    // Getter and Setter methods
    public long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "AccountDetails [accountNumber=" + accountNumber +
               ", customerName=" + customerName +
               ", balance=" + balance + "]";
    }
}
