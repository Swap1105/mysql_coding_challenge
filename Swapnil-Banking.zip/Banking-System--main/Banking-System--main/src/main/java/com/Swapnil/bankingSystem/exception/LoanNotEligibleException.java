package com.Swapnil.bankingSystem.exception;

public class LoanNotEligibleException extends Exception {
    public LoanNotEligibleException(String message) {
        super(message);
    }
}
