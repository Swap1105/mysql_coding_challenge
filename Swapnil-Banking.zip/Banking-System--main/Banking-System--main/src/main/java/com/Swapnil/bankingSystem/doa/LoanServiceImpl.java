package com.Swapnil.bankingSystem.doa;

import com.Swapnil.bankingSystem.entity.Customer;
import com.Swapnil.bankingSystem.exception.LoanNotEligibleException;

public class LoanServiceImpl implements LoanService {
    @Override
    public boolean isEligibleForLoan(Customer customer) throws LoanNotEligibleException {
        if (customer.getCreditScore() > 700 && customer.getAnnualIncome() >= 50000) {
            return true;
        } else {
            throw new LoanNotEligibleException("Credit Score must be above 700 and income at least $50,000");
        }
    }
}