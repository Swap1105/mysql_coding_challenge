package com.Swapnil.bankingSystem.entity;

public class Customer {
    private int creditScore;
    private double annualIncome;
    //for task 14 start here
    private int customerId;
    private String firstName;
    private String lastName;
    private String dob;
    private String email;
    private String phoneNumber;
    private String address;
  //end
    public Customer(int creditScore, double annualIncome) {
        this.creditScore = creditScore;
        this.annualIncome = annualIncome;
    }

    public int getCreditScore() {
        return creditScore;
    }

    public double getAnnualIncome() {
        return annualIncome;
    }
}