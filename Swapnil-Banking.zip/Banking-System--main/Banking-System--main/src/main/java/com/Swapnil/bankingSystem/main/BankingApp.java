package com.Swapnil.bankingSystem.main;

import com.Swapnil.bankingSystem.doa.BankDAO;
import com.Swapnil.bankingSystem.entity.AccountDetails;
import com.Swapnil.bankingSystem.exception.InvalidAccountException;

import java.util.List;
import java.util.Scanner;

public class BankingApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BankDAO dao = new BankDAO();
        boolean exit = false;

        while (!exit) {
            System.out.println("\n Welcome to HM Bank ");
            System.out.println("1. Add Account");
            System.out.println("2. View Account by ID");
            System.out.println("3. View All Accounts");
            System.out.println("4. Update Account");
            System.out.println("5. Delete Account");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter customer ID: ");
                        int custId = sc.nextInt();
                        sc.nextLine(); // consume newline
                        System.out.print("Enter account type (savings/current/zero_balance): ");
                        String type = sc.nextLine();
                        System.out.print("Enter initial balance: ");
                        float bal = sc.nextFloat();

                        // Validate input before adding account
                        if (bal < 0) {
                            System.out.println("Initial balance cannot be negative. Please try again.");
                        } else {
                            dao.addAccount(new AccountDetails(custId, type, bal));
                            System.out.println("✅ Account added successfully!");
                        }

                    case 2:
                        System.out.print("Enter account ID: ");
                        int accId = sc.nextInt();
                        AccountDetails acc = dao.getAccount(accId);
                        if (acc != null) {
                            System.out.println("Account Found:");
                            System.out.println(acc);
                        } else {
                            System.out.println("Account not found.");
                        }
                        break;

                    case 3:
                        List<AccountDetails> all = dao.getAllAccounts();
                        System.out.println("All Accounts:");
                        for (AccountDetails a : all) {
                            System.out.println(a);
                        }
                        break;

                    case 4:
                        System.out.print("Enter account ID to update: ");
                        int updId = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter new customer ID: ");
                        String newType = sc.nextLine();
                        System.out.print("Enter new balance: ");
                        float newBal = sc.nextFloat();
                        dao.updateAccount(new AccountDetails(updId, newType, newBal));
                        System.out.println("Account updated.");
                        break;

                    case 5:
                        System.out.print("Enter account ID to delete: ");
                        int delId = sc.nextInt();
                          int res=  dao.deleteAccount(delId);
                          if(res>0){
                            System.out.println("🗑 Account deleted successfully.");
                        } else {
                         throw new InvalidAccountException("Account does not exist. Deletion aborted.");
                        }

                        break;

                    case 6:
                        exit = true;
                        System.out.println("Thank you for using HM Bank. Bye!");
                        break;

                    default:
                        System.out.println("Invalid choice, try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());

            }
        }

        sc.close();
    }
}
