package com.Swapnil.bankingSystem.main;

import java.util.Scanner;

public class PasswordValidator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Create your password: ");
        String password = sc.nextLine();

        boolean isValid = true;

        if (password.length() < 8) {
            System.out.println("Password must be at least 8 characters long.");
            isValid = false;
        }

        if (!password.matches(".*[A-Z].*")) {
            System.out.println("Password must contain at least one uppercase letter.");
            isValid = false;
        }

        if (!password.matches(".*\\d.*")) {
            System.out.println("Password must contain at least one digit.");
            isValid = false;
        }

        if (isValid) {
            System.out.println("Password is valid! Your account is secured.");
        } else {
            System.out.println("Please try again with a stronger password.");
        }

        sc.close();
    }
}
