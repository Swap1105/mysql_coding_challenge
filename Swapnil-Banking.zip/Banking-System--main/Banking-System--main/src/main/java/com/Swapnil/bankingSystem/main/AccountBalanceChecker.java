package com.Swapnil.bankingSystem.main;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class AccountBalanceChecker {
    public static void main(String[] args) {
        // Predefined customer accounts (account number -> balance)
        Map<String, Double> accountMap = new HashMap<>();
        accountMap.put("1001", 5000.50);
        accountMap.put("1002", 12000.00);
        accountMap.put("1003", 7500.75);
        accountMap.put("1004", 23000.30);

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.print("Enter your account number (or type 'exit' to quit): ");
            String accNum = sc.next();

            if (accNum.equalsIgnoreCase("exit")) {
                System.out.println("Thank you for banking with us!");
                break;
            }

            if (accountMap.containsKey(accNum)) {
                System.out.printf("Account Found! Your balance is: ₹%.2f\n", accountMap.get(accNum));
            } else {
                System.out.println("Invalid account number. Please try again.\n");
            }
        }

        sc.close();
    }
}
