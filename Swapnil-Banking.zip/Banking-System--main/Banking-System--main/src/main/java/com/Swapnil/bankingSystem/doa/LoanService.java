package com.Swapnil.bankingSystem.doa;

import com.Swapnil.bankingSystem.entity.Customer;
import com.Swapnil.bankingSystem.exception.LoanNotEligibleException;

public interface LoanService {
    boolean isEligibleForLoan(Customer customer) throws LoanNotEligibleException;
}
